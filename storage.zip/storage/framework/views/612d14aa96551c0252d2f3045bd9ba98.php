

<?php $__env->startSection('title', 'Penugasan Dosen'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h1 class="mb-4">Penugasan Dosen dan Kelas</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Terjadi Kesalahan:</strong>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        
        <div class="card mb-4">
            <div class="card-header">Filter Data</div>
            <div class="card-body">
                <form action="<?php echo e(route('penugasan.index')); ?>" method="GET">
                    <div class="row g-3 align-items-end">
                        <div class="col-md-4">
                            <label for="prodi_id" class="form-label">Pilih Prodi:</label>
                            <select name="prodi_id" id="prodi_id" class="form-select" onchange="this.form.submit()">
                                <option value="">Semua Prodi</option>
                                <?php $__currentLoopData = $allProdi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>" <?php echo e(($prodiId ?? '') == $p->id ? 'selected' : ''); ?>>
                                        <?php echo e($p->nama_prodi); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            
                            <label for="jenis_semester" class="form-label">Pilih Semester:</label>
                            <select name="jenis_semester" id="jenis_semester" class="form-select"
                                onchange="this.form.submit()">
                                <option value="gasal" <?php echo e(($jenisSemester ?? 'gasal') == 'gasal' ? 'selected' : ''); ?>>Gasal
                                </option>
                                <option value="genap" <?php echo e(($jenisSemester ?? '') == 'genap' ? 'selected' : ''); ?>>Genap
                                </option>
                            </select>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        
        <form action="<?php echo e(route('penugasan.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="jenis_semester" value="<?php echo e($jenisSemester ?? 'gasal'); ?>">
            <input type="hidden" name="prodi_id" value="<?php echo e($prodiId ?? ''); ?>">

            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th style="width: 25%;">Mata Kuliah (SKS)</th>
                            <th style="width: 15%;">Kelas</th>
                            <th style="width: 45%;">Dosen Pengampu</th>
                            <th style="width: 15%; text-align: center;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $mataKuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $kelasTerkait = $allKelas
                                    ->where('semester', $mk->semester)
                                    ->where('prodi_id', $mk->prodi_id);
                                $dosenTerkait = $allDosen->filter(
                                    fn($dosen) => $dosen->prodi->pluck('id')->contains($mk->prodi_id),
                                );
                                $penugasanSaatIni = $penugasan->where('mata_kuliah_id', $mk->id);
                                $rowspanCount = $kelasTerkait->count() > 0 ? $kelasTerkait->count() : 1;
                            ?>

                            <?php $__empty_2 = true; $__currentLoopData = $kelasTerkait; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <tr>
                                    <?php if($loop->first): ?>
                                        <td rowspan="<?php echo e($rowspanCount); ?>">
                                            <strong><?php echo e($mk->nama_mk); ?></strong> (<?php echo e($mk->sks); ?> SKS)
                                        </td>
                                    <?php endif; ?>

                                    <td><?php echo e($kelas->nama_kelas); ?></td>

                                    <td>
                                        <div class="input-group">
                                            <input type="text" class="form-control search-dosen-input"
                                                placeholder="Cari Nama/NIDN Dosen..."
                                                id="search_dosen_<?php echo e($mk->id); ?>_<?php echo e($kelas->id); ?>">
                                            <select name="assignments[<?php echo e($mk->id); ?>_<?php echo e($kelas->id); ?>][dosen_id]"
                                                class="form-select dosen-select"
                                                id="dosen_select_<?php echo e($mk->id); ?>_<?php echo e($kelas->id); ?>">
                                                <option value="">Pilih Dosen</option>
                                                <?php $__currentLoopData = $dosenTerkait; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $isSelected = $penugasanSaatIni
                                                            ->where('kelas_id', $kelas->id)
                                                            ->where('dosen_id', $dosen->id)
                                                            ->isNotEmpty();
                                                    ?>
                                                    <option value="<?php echo e($dosen->id); ?>"
                                                        <?php echo e($isSelected ? 'selected' : ''); ?>>
                                                        <?php echo e($dosen->nama_dosen); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <input type="hidden"
                                            name="assignments[<?php echo e($mk->id); ?>_<?php echo e($kelas->id); ?>][mata_kuliah_id]"
                                            value="<?php echo e($mk->id); ?>">
                                        <input type="hidden"
                                            name="assignments[<?php echo e($mk->id); ?>_<?php echo e($kelas->id); ?>][kelas_id]"
                                            value="<?php echo e($kelas->id); ?>">
                                    </td>

                                    <td class="text-center">
                                        <?php
                                            $penugasanItem = $penugasanSaatIni->where('kelas_id', $kelas->id)->first();
                                        ?>
                                        <?php if($penugasanItem): ?>
                                            <button type="button" class="btn btn-danger btn-sm delete-btn"
                                                data-url="<?php echo e(route('penugasan.destroy', $penugasanItem->id)); ?>">
                                                Hapus
                                            </button>
                                        <?php else: ?>
                                            <button type="button" class="btn btn-secondary btn-sm" disabled>Hapus</button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <tr>
                                    <td><strong><?php echo e($mk->nama_mk); ?></strong> (<?php echo e($mk->sks); ?> SKS)</td>
                                    <td colspan="3" class="text-center text-muted">
                                        <em>Tidak ada kelas yang ditemukan untuk mata kuliah ini.</em>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center p-5">
                                    <h5>Data Tidak Ditemukan</h5>
                                    <p class="text-muted">Silakan pilih Prodi dan Semester pada filter di atas.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary btn-lg">Simpan Semua Perubahan</button>
            </div>
        </form>
    </div>

    
    <form method="POST" id="delete-form" style="display: none;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // --- Script untuk search dosen ---
            document.querySelectorAll('.search-dosen-input').forEach(input => {
                input.addEventListener('keyup', function() {
                    const searchValue = this.value.toLowerCase().trim();
                    const selectElement = this.nextElementSibling;
                    selectElement.querySelectorAll('option').forEach(option => {
                        if (option.value === "") return;
                        option.style.display = option.textContent.toLowerCase().includes(
                            searchValue) ? '' : 'none';
                    });
                });
            });

            // --- Script untuk menghandle tombol Hapus ---
            const deleteForm = document.getElementById('delete-form');
            document.querySelectorAll('.delete-btn').forEach(button => {
                button.addEventListener('click', function() {
                    if (confirm('Anda yakin ingin menghapus penugasan ini?')) {
                        const url = this.dataset.url;
                        deleteForm.action = url;
                        deleteForm.submit();
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\2212801141\resources\views/penugasan.blade.php ENDPATH**/ ?>