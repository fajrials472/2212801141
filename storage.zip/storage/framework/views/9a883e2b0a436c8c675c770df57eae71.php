

<?php $__env->startSection('title', 'Dashboard Dosen'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card" style="min-width: 1200px;">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h3 class="card-title mb-0">Jadwal Mengajar Anda</h3>
                
                <a href="<?php echo e(route('dosen.jadwal.cetak', ['tahun_ajaran' => request('tahun_ajaran'), 'jenis_semester' => request('jenis_semester')])); ?>"
                    class="btn btn-light btn-sm" target="_blank">
                    <i class="fas fa-print"></i> Cetak Jadwal
                </a>
            </div>
            <div class="card-body">
                
                <div class="row mb-4 align-items-center">
                    <div class="col-md-8">
                        <form action="<?php echo e(route('dosen.dashboard')); ?>" method="GET" id="filter-form">
                            <div class="row align-items-end">
                                <div class="col-auto">
                                    <label for="tahun_ajaran" class="form-label fw-bold">TAHUN AJARAN</label>
                                    <select name="tahun_ajaran" id="tahun_ajaran" class="form-select"
                                        onchange="this.form.submit()">
                                        <option value="">Pilih Tahun Ajaran</option>
                                        <?php $__currentLoopData = $allTahunAjaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tahun); ?>"
                                                <?php echo e(($tahunAjaran ?? '') == $tahun ? 'selected' : ''); ?>>
                                                <?php echo e($tahun); ?>/<?php echo e($tahun + 1); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-auto">
                                    <label for="jenis_semester" class="form-label fw-bold">SEMESTER</label>
                                    <select name="jenis_semester" id="jenis_semester" class="form-select"
                                        onchange="this.form.submit()">
                                        <option value="">Semua</option>
                                        <option value="gasal" <?php echo e(($jenisSemester ?? '') == 'gasal' ? 'selected' : ''); ?>>
                                            Gasal</option>
                                        <option value="genap" <?php echo e(($jenisSemester ?? '') == 'genap' ? 'selected' : ''); ?>>
                                            Genap</option>
                                    </select>
                                </div>
                                <div class="col-auto">
                                    <a href="<?php echo e(route('dosen.dashboard')); ?>" class="btn btn-secondary">Reset</a>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-4 d-flex justify-content-end">
                        <div class="text-end p-2 border rounded bg-light" style="min-width: 300px;">
                            <h5 class="mb-0"><?php echo e($dosen->nama_dosen); ?></h5>
                            <p class="text-muted mb-0">NIDN: <?php echo e($dosen->nidn ?? 'Tidak tersedia'); ?></p>
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered text-center align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th style="width: 10%;">HARI</th>
                                <th style="width: 15%;">JAM</th>
                                <th style="width: 30%;">MATAKULIAH</th>
                                <th style="width: 10%;">SEMESTER</th>
                                <th style="width: 15%;">KELAS</th>
                                <th style="width: 20%;">RUANGAN</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $jadwalGroupedByDay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari => $jadwalsOnThisDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php $__currentLoopData = $jadwalsOnThisDay->sortBy('jam_mulai'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php if($loop->first): ?>
                                            <td rowspan="<?php echo e(count($jadwalsOnThisDay)); ?>">
                                                <strong><?php echo e($hari); ?></strong></td>
                                        <?php endif; ?>

                                        <td><?php echo e(date('H:i', strtotime($jadwal->jam_mulai))); ?> -
                                            <?php echo e(date('H:i', strtotime($jadwal->jam_selesai))); ?></td>
                                        <td class="text-start"><?php echo e($jadwal->penugasan->mataKuliah->nama_mk ?? 'N/A'); ?></td>
                                        <td><?php echo e($jadwal->penugasan->mataKuliah->semester ?? 'N/A'); ?></td>
                                        <td><?php echo e($jadwal->penugasan->kelas->nama_kelas ?? 'N/A'); ?></td>
                                        <td><?php echo e($jadwal->ruangan->nama_ruangan ?? 'N/A'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="p-5">
                                        <h4>Jadwal tidak ditemukan.</h4>
                                        <p class="text-muted">Tidak ada jadwal yang cocok dengan filter yang Anda pilih.</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\221280114\resources\views/dosen/dashboard.blade.php ENDPATH**/ ?>