<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Dashboard - <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">


    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        .sidebar {
            height: 100vh;
            background-color: #343a40;
            padding-top: 20px;
            position: fixed;
            top: 0;
            left: 0;
        }

        .sidebar a {
            color: #adb5bd;
            padding: 10px 15px;
            display: block;
            text-decoration: none;
        }

        .sidebar a:hover, .sidebar a.active {
            background-color: #495057;
            color: #fff;
        }

        .content-wrapper {
            margin-left: 250px;
        }
    </style>
</head>

<body class="font-sans antialiased">
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar text-white p-3 d-none d-md-block" style="width: 250px;">
            <?php if(auth()->guard()->check()): ?>
                <h4 class="mb-4">
                    <?php if(Auth::user()->role === 'admin'): ?>
                        Admin Panel
                    <?php elseif(Auth::user()->role === 'dosen'): ?>
                        Dosen Panel
                    <?php else: ?>
                        Mahasiswa Panel
                    <?php endif; ?>
                </h4>
                <p class="text-white-50">Login sebagai: <?php echo e(Auth::user()->name); ?></p>
                <hr class="text-white">
            <?php endif; ?>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                </li>
                
                
                <?php if(in_array(Auth::user()->role, ['dosen', 'mahasiswa'])): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('profile.edit') ? 'active' : ''); ?>" href="<?php echo e(route('profile.edit')); ?>">Profil Saya</a>
                    </li>
                <?php endif; ?>


                <?php if(Auth::user()->role === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('prodi.index')); ?>">Manajemen Prodi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('dosen.index')); ?>">Manajemen Dosen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('mata-kuliah.index')); ?>">Manajemen Mata Kuliah</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('ruangan.index')); ?>">Manajemen Ruangan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('kelas.index')); ?>">Manajemen Kelas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('mahasiswa.index')); ?>">Manajemen Mahasiswa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('penugasan.index')); ?>">Penugasan Dosen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('jadwal.index')); ?>">Generate Jadwal</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('jadwal.lihat')); ?>">Lihat Jadwal Per Kelas</a>
                    </li>
                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item">
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault(); this.closest('form').submit();">
                                Logout
                            </a>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
        </div>

        <!-- Page Content -->
        <div class="content-wrapper">
            <main class="py-4 px-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php /**PATH C:\laragon\www\221280104\resources\views/layouts/app.blade.php ENDPATH**/ ?>