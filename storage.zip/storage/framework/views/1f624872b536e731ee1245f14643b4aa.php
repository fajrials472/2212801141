

<?php $__env->startSection('title', 'Jadwal Kuliah'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        
        <div class="card mb-4">
            <div class="card-header">Opsi Jadwal</div>
            <div class="card-body">
                <div class="row align-items-center">

                    
                    <div class="col-md-6 mb-3 mb-md-0 border-end">
                        <form action="<?php echo e(route('jadwal.generate')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <h5 class="mb-3">Generate Jadwal Baru</h5>
                            <div class="row">
                                <div class="col-md-5">
                                    <label for="tahun_ajaran" class="form-label">Pilih Tahun Ajaran</label>
                                    <select name="tahun_ajaran" id="tahun_ajaran" class="form-select" required>
                                        <option value="">-- Pilih Tahun --</option>
                                        <?php $__currentLoopData = $allTahunAjaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tahun); ?>"><?php echo e($tahun); ?>/<?php echo e($tahun + 1); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-5">
                                    <label for="jenis_semester_gen" class="form-label">Pilih Semester</label>
                                    <select name="jenis_semester" id="jenis_semester_gen" class="form-select" required>
                                        <option value="">-- Pilih Semester --</option>
                                        <option value="gasal">Gasal</option>
                                        <option value="genap">Genap</option>
                                    </select>
                                </div>
                                <div class="col-md-2 d-flex align-items-end">
                                    <button type="submit" class="btn btn-primary w-100"
                                        onclick="return confirm('Yakin ingin membuat jadwal baru untuk periode ini? Jadwal lama di periode ini akan diarsipkan.')">
                                        Generate
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="col-md-6">
                        <form action="<?php echo e(route('jadwal.index')); ?>" method="GET" id="filter-form">
                            <h5 class="mb-3">Filter Tampilan Jadwal</h5>
                            <div class="row g-3 align-items-end">
                                <div class="col-md-4">
                                    <label for="prodi_id" class="form-label">Prodi</label>
                                    <select name="prodi_id" id="prodi_id" class="form-select"
                                        onchange="this.form.submit()">
                                        <option value="">Semua Prodi</option>
                                        <?php $__currentLoopData = $allProdi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($prodi->id); ?>"
                                                <?php echo e(($prodiId ?? '') == $prodi->id ? 'selected' : ''); ?>>
                                                <?php echo e($prodi->nama_prodi); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label for="jenis_semester" class="form-label">Semester</label>
                                    <select name="jenis_semester" id="jenis_semester" class="form-select"
                                        onchange="this.form.submit()">
                                        <option value="">Semua Semester</option>
                                        <option value="gasal" <?php echo e(($jenisSemester ?? '') == 'gasal' ? 'selected' : ''); ?>>
                                            Gasal</option>
                                        <option value="genap" <?php echo e(($jenisSemester ?? '') == 'genap' ? 'selected' : ''); ?>>
                                            Genap</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <a href="<?php echo e(route('jadwal.index')); ?>" class="btn btn-secondary w-100">Reset Filter</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        
        <?php if($jadwal->isNotEmpty()): ?>
            <div class="card w-100" style="min-width: 1200px;">
                <div class="card-header d-flex justify-content-between">
                    <h3 class="card-title mb-0">Rekap Jadwal (Aktif Saat Ini)</h3>
                    <a href="<?php echo e(route('jadwal.cetak', request()->query())); ?>" class="btn btn-sm btn-info"
                        target="_blank">Cetak Jadwal</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered text-center align-middle">
                            <thead class="table-dark">
                                <tr>
                                    <th style="width: 10%;">HARI</th>
                                    <th style="width: 15%;">WAKTU</th>
                                    <th style="width: 25%;">MATA KULIAH</th>
                                    <th style="width: 15%;">KELAS</th>
                                    <th style="width: 20%;">DOSEN</th>
                                    <th style="width: 15%;">RUANGAN</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $allJadwals = $jadwal->flatten();
                                    $dayOrder = [
                                        'Senin' => 1,
                                        'Selasa' => 2,
                                        'Rabu' => 3,
                                        'Kamis' => 4,
                                        'Jumat' => 5,
                                        'Sabtu' => 6,
                                    ];
                                    $jadwalGroupedByDay = $allJadwals
                                        ->sortBy(fn($j) => $dayOrder[$j->hari] ?? 99)
                                        ->groupBy('hari');
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $jadwalGroupedByDay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari => $jadwalsOnThisDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php $__currentLoopData = $jadwalsOnThisDay->sortBy('jam_mulai'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php if($loop->first): ?>
                                                <td rowspan="<?php echo e(count($jadwalsOnThisDay)); ?>">
                                                    <strong><?php echo e($hari); ?></strong></td>
                                            <?php endif; ?>
                                            <td><?php echo e(date('H:i', strtotime($item->jam_mulai))); ?> -
                                                <?php echo e(date('H:i', strtotime($item->jam_selesai))); ?></td>
                                            <td class="text-start">
                                                <?php echo e($item->penugasan->mataKuliah->nama_mk ?? 'N/A'); ?> <br>
                                                <small class="text-muted">Semester:
                                                    <?php echo e($item->penugasan->mataKuliah->semester ?? 'N/A'); ?></small>
                                            </td>
                                            <td><?php echo e($item->penugasan->kelas->nama_kelas ?? 'N/A'); ?></td>
                                            <td class="text-start"><?php echo e($item->penugasan->dosen->nama_dosen ?? 'N/A'); ?></td>
                                            <td><?php echo e($item->ruangan->nama_ruangan ?? 'N/A'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="p-5">Tidak ada jadwal untuk ditampilkan.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-info text-center">
                <h4>Jadwal Aktif Kosong.</h4>
                <p class="text-muted mb-0">Silakan generate jadwal baru untuk periode yang diinginkan.</p>
            </div>
        <?php endif; ?>

        
        <div class="card mt-5">
            <div class="card-header">
                <h3 class="card-title">Arsip Jadwal Terdahulu</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Nama Versi Jadwal</th>
                                <th>Tanggal Diarsipkan</th>
                                <th style="width: 15%;" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $arsipJadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arsip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($arsip->nama_versi); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($arsip->created_at)->format('d M Y H:i')); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('arsip.jadwal.show', $arsip->id)); ?>"
                                            class="btn btn-info btn-sm">Lihat</a>
                                        <form action="<?php echo e(route('arsip.jadwal.destroy', $arsip->id)); ?>" method="POST"
                                            class="d-inline"
                                            onsubmit="return confirm('Yakin ingin menghapus arsip ini secara permanen?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button typeM="submit" class="btn btn-danger btn-sm">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center">Belum ada arsip jadwal.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-end mt-3">
                    <?php echo e($arsipJadwal->links()); ?>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\2212801141\resources\views/jadwal.blade.php ENDPATH**/ ?>