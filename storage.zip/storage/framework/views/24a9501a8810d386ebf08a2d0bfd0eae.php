

<?php $__env->startSection('title', 'Dashboard Dosen'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        
        <div class="card" style="min-width: 1200px;">
            <div class="card-header bg-primary text-white">
                <h3 class="card-title mb-0">Jadwal Mengajar Anda</h3>
            </div>
            <div class="card-body">
                
                <div class="row mb-4 align-items-center">
                    <div class="col-md-6">
                        <form action="<?php echo e(route('dosen.dashboard')); ?>" method="GET" id="filter-semester-form">
                            <table class="table table-sm table-borderless mb-0">
                                <tbody>
                                    <tr>
                                        <th style="width: 150px;">
                                            <label for="jenis_semester" class="form-label mb-0">FILTER SEMESTER</label>
                                        </th>
                                        <td>
                                            <select name="jenis_semester" id="jenis_semester" class="form-select w-auto"
                                                onchange="this.form.submit()">
                                                <option value="">Semua Semester</option>
                                                <option value="gasal"
                                                    <?php echo e(($jenisSemester ?? '') == 'gasal' ? 'selected' : ''); ?>>Gasal</option>
                                                <option value="genap"
                                                    <?php echo e(($jenisSemester ?? '') == 'genap' ? 'selected' : ''); ?>>Genap</option>
                                            </select>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </form>
                    </div>
                    <div class="col-md-6 d-flex justify-content-end align-items-center">
                        
                        <a href="<?php echo e(route('dosen.jadwal.cetak')); ?>" class="btn btn-success me-3" target="_blank">
                            <i class="fas fa-print"></i> Cetak Jadwal
                        </a>
                        <div class="text-end p-2 border rounded bg-light" style="min-width: 300px;">
                            <h5 class="mb-0"><?php echo e($dosen->nama_dosen); ?></h5>
                            <p class="text-muted mb-0">NIDN: <?php echo e($dosen->nidn ?? 'Tidak tersedia'); ?></p>
                        </div>
                    </div>
                </div>

                
                <div class="table-responsive">
                    <table class="table table-bordered text-center align-middle">
                        <thead class="table-dark">
                            <tr>
                                
                                <th style="width: 10%;">HARI</th>
                                <th style="width: 15%;">JAM</th>
                                <th style="width: 30%;">MATAKULIAH</th>
                                <th style="width: 10%;">SEMESTER</th>
                                <th style="width: 15%;">KELAS</th>
                                <th style="width: 20%;">RUANGAN</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $jadwalGroupedByDay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari => $jadwalsOnThisDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php $__currentLoopData = $jadwalsOnThisDay->sortBy('jam_mulai'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php if($loop->first): ?>
                                            <td rowspan="<?php echo e(count($jadwalsOnThisDay)); ?>">
                                                <strong><?php echo e($hari); ?></strong>
                                            </td>
                                        <?php endif; ?>

                                        <td><?php echo e(date('H:i', strtotime($jadwal->jam_mulai))); ?> -
                                            <?php echo e(date('H:i', strtotime($jadwal->jam_selesai))); ?></td>
                                        <td class="text-start"><?php echo e($jadwal->penugasan->mataKuliah->nama_mk ?? 'N/A'); ?></td>
                                        <td><?php echo e($jadwal->penugasan->kelas->semester ?? 'N/A'); ?></td>
                                        <td><?php echo e($jadwal->penugasan->kelas->nama_kelas ?? 'N/A'); ?></td>
                                        <td><?php echo e($jadwal->ruangan->nama_ruangan ?? 'N/A'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="p-5">
                                        <h4>Jadwal tidak ditemukan.</h4>
                                        <p class="text-muted">Tidak ada jadwal yang cocok dengan filter angkatan yang
                                            dipilih.</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\221280104\resources\views/dosen/dashboard.blade.php ENDPATH**/ ?>