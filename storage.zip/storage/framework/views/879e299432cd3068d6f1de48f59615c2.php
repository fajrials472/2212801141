

<?php $__env->startSection('title', 'Lihat Arsip Jadwal'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h1 class="mb-4">Arsip Jadwal: <?php echo e($versi->nama_versi); ?></h1>
        <a href="<?php echo e(route('jadwal.index')); ?>" class="btn btn-secondary mb-4">Kembali ke Jadwal Aktif</a>

        <?php if($jadwal->isNotEmpty()): ?>
            <div class="card w-100" style="min-width: 1200px;">
                <div class="card-header d-flex justify-content-between">
                    <h3 class="card-title mb-0">Detail Arsip Jadwal</h3>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaKelas => $jadwalsByKelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-5">
                            <h4 class="mb-3">Kelas: <strong><?php echo e($namaKelas); ?></strong></h4>
                            <div class="table-responsive">
                                <table class="table table-bordered text-center align-middle">
                                    <thead class="table-dark">
                                        <tr>
                                            <th style="width: 10%;">HARI</th>
                                            <th style="width: 15%;">WAKTU</th>
                                            <th style="width: 30%;">MATA KULIAH</th>
                                            <th style="width: 25%;">DOSEN</th>
                                            <th style="width: 20%;">RUANGAN</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $dayOrder = [
                                                'Senin' => 1,
                                                'Selasa' => 2,
                                                'Rabu' => 3,
                                                'Kamis' => 4,
                                                'Jumat' => 5,
                                                'Sabtu' => 6,
                                            ];
                                            $jadwalGroupedByDay = $jadwalsByKelas
                                                ->sortBy(function ($jadwal) use ($dayOrder) {
                                                    return $dayOrder[$jadwal->hari] ?? 99;
                                                })
                                                ->groupBy('hari');
                                        ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $jadwalGroupedByDay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari => $jadwalsOnThisDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php $__currentLoopData = $jadwalsOnThisDay->sortBy('jam_mulai'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <?php if($loop->first): ?>
                                                        <td rowspan="<?php echo e(count($jadwalsOnThisDay)); ?>">
                                                            <strong><?php echo e($hari); ?></strong></td>
                                                    <?php endif; ?>
                                                    <td><?php echo e(date('H:i', strtotime($item->jam_mulai))); ?> -
                                                        <?php echo e(date('H:i', strtotime($item->jam_selesai))); ?></td>
                                                    <td class="text-start">
                                                        <?php echo e($item->nama_mk ?? 'N/A'); ?> <br>
                                                        <small class="text-muted">Semester:
                                                            <?php echo e($item->semester ?? 'N/A'); ?></small>
                                                    </td>
                                                    <td class="text-start"><?php echo e($item->nama_dosen ?? 'N/A'); ?></td>
                                                    <td><?php echo e($item->nama_ruangan ?? 'N/A'); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="5" class="p-5">Tidak ada jadwal untuk kelas ini.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-info text-center">
                <h4>Arsip Jadwal Kosong.</h4>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\2212801141\resources\views/arsip_jadwal_show.blade.php ENDPATH**/ ?>