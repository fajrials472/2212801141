

<?php $__env->startSection('title', 'Jadwal Kuliah'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        
        <div class="card w-100" style="min-width: 1200px;">
            <div class="card-header">Opsi Jadwal</div>
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-3 mb-3 mb-md-0">
                        <form action="<?php echo e(route('jadwal.generate')); ?>" method="POST" class="d-grid">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-primary"
                                onclick="return confirm('Yakin ingin membuat jadwal baru? Jadwal lama akan dihapus.')">
                                Generate Jadwal Baru
                            </button>
                        </form>
                    </div>
                    <div class="col-md-9">
                        <form action="<?php echo e(route('jadwal.index')); ?>" method="GET" id="filter-form">
                            <div class="row g-3 align-items-end">
                                <div class="col-md-4">
                                    <label for="prodi_id" class="form-label">Prodi</label>
                                    <select name="prodi_id" id="prodi_id" class="form-select"
                                        onchange="this.form.submit()">
                                        <option value="">Semua Prodi</option>
                                        <?php $__currentLoopData = $allProdi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($prodi->id); ?>"
                                                <?php echo e(($prodiId ?? '') == $prodi->id ? 'selected' : ''); ?>>
                                                <?php echo e($prodi->nama_prodi); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label for="jenis_semester" class="form-label">Semester</label>
                                    <select name="jenis_semester" id="jenis_semester" class="form-select"
                                        onchange="this.form.submit()">
                                        <option value="">Semua Semester</option>
                                        <option value="gasal" <?php echo e(($jenisSemester ?? '') == 'gasal' ? 'selected' : ''); ?>>
                                            Gasal</option>
                                        <option value="genap" <?php echo e(($jenisSemester ?? '') == 'genap' ? 'selected' : ''); ?>>
                                            Genap</option>
                                    </select>
                                </div>
                                <div class="col-md-4 d-flex align-items-end">
                                    <a href="<?php echo e(route('jadwal.index')); ?>" class="btn btn-secondary w-100">Reset
                                        Filter</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        
        <?php if($jadwal->isNotEmpty()): ?>
            <div class="card w-100" style="min-width: 1200px;">
                <div class="card-header d-flex justify-content-between">
                    <h3 class="card-title mb-0">Rekap Jadwal</h3>
                    
                    <a href="<?php echo e(route('jadwal.cetak', ['prodi_id' => $prodiId, 'jenis_semester' => $jenisSemester])); ?>"
                        target="_blank" class="btn btn-sm btn-info">
                        <i class="fas fa-print"></i> Cetak Jadwal
                    </a>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaKelas => $jadwalsByKelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-5">
                            <h4 class="mb-3">Kelas: <strong><?php echo e($namaKelas); ?></strong></h4>
                            <div class="table-responsive">
                                <table class="table table-bordered text-center align-middle">
                                    <thead class="table-dark">
                                        <tr>
                                            <th style="width: 10%;">HARI</th>
                                            <th style="width: 15%;">WAKTU</th>
                                            <th style="width: 30%;">MATA KULIAH</th>
                                            <th style="width: 25%;">DOSEN</th>
                                            <th style="width: 20%;">RUANGAN</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            // Mengurutkan hari dengan benar
                                            $dayOrder = [
                                                'Senin' => 1,
                                                'Selasa' => 2,
                                                'Rabu' => 3,
                                                'Kamis' => 4,
                                                'Jumat' => 5,
                                                'Sabtu' => 6,
                                            ];
                                            $jadwalGroupedByDay = $jadwalsByKelas
                                                ->sortBy(function ($jadwal) use ($dayOrder) {
                                                    return $dayOrder[$jadwal->hari] ?? 99;
                                                })
                                                ->groupBy('hari');
                                        ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $jadwalGroupedByDay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari => $jadwalsOnThisDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php $__currentLoopData = $jadwalsOnThisDay->sortBy('jam_mulai'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <?php if($loop->first): ?>
                                                        <td rowspan="<?php echo e(count($jadwalsOnThisDay)); ?>">
                                                            <strong><?php echo e($hari); ?></strong>
                                                        </td>
                                                    <?php endif; ?>
                                                    <td><?php echo e(date('H:i', strtotime($item->jam_mulai))); ?> -
                                                        <?php echo e(date('H:i', strtotime($item->jam_selesai))); ?></td>
                                                    <td class="text-start">
                                                        <?php echo e($item->penugasan->mataKuliah->nama_mk ?? 'N/A'); ?> <br>
                                                    </td>
                                                    <td class="text-start">
                                                        <?php echo e($item->penugasan->dosen->nama_dosen ?? 'N/A'); ?></td>
                                                    <td><?php echo e($item->ruangan->nama_ruangan ?? 'N/A'); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="5" class="p-5">Tidak ada jadwal untuk kelas ini.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-info text-center">
                <h4>Jadwal tidak ditemukan.</h4>
                <p class="text-muted mb-0">Silakan gunakan filter di atas atau generate jadwal baru jika belum ada.</p>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\221280104\resources\views/jadwal.blade.php ENDPATH**/ ?>