<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Dashboard Admin</h1>

    
    <div class="row">
        <div class="col-lg-3 col-6">
            <div class="small-box bg-info p-3 rounded text-white mb-3" style="position: relative;">
                <div class="inner">
                    <h3><?php echo e($totalDosen); ?></h3>
                    <p>Total Dosen</p>
                </div>
                <div class="icon fs-1 opacity-25" style="position: absolute; top: 15px; right: 15px;">
                    <i class="fas fa-user-tie"></i>
                </div>
                <a href="<?php echo e(route('dosen.index')); ?>" class="small-box-footer text-white text-decoration-none">
                    Lihat Detail <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-success p-3 rounded text-white mb-3" style="position: relative;">
                <div class="inner">
                    <h3><?php echo e($totalMahasiswa); ?></h3>
                    <p>Total Mahasiswa</p>
                </div>
                <div class="icon fs-1 opacity-25" style="position: absolute; top: 15px; right: 15px;">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <a href="<?php echo e(route('mahasiswa.index')); ?>" class="small-box-footer text-white text-decoration-none">
                    Lihat Detail <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-warning p-3 rounded text-dark mb-3" style="position: relative;">
                <div class="inner">
                    <h3><?php echo e($totalMataKuliah); ?></h3>
                    <p>Total Mata Kuliah</p>
                </div>
                <div class="icon fs-1 opacity-25" style="position: absolute; top: 15px; right: 15px;">
                    <i class="fas fa-book"></i>
                </div>
                <a href="<?php echo e(route('mata-kuliah.index')); ?>" class="small-box-footer text-dark text-decoration-none">
                    Lihat Detail <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-danger p-3 rounded text-white mb-3" style="position: relative;">
                <div class="inner">
                    <h3><?php echo e($totalKelas); ?></h3>
                    <p>Total Kelas</p>
                </div>
                <div class="icon fs-1 opacity-25" style="position: absolute; top: 15px; right: 15px;">
                    <i class="fas fa-school"></i>
                </div>
                <a href="<?php echo e(route('kelas.index')); ?>" class="small-box-footer text-white text-decoration-none">
                    Lihat Detail <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
    </div>

    
    <div class="row mt-4">
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-download me-2"></i>Download Data Mahasiswa</h3>
                </div>
                
                <form action="<?php echo e(route('mahasiswa.download')); ?>" method="GET" target="_blank">
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="kelas_id" class="form-label">Berdasarkan Kelas</label>
                            <select name="kelas_id" id="kelas_id" class="form-select">
                                <option value="semua">-- Semua Kelas --</option>
                                <?php $__currentLoopData = $allKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kelas->id); ?>"><?php echo e($kelas->nama_kelas); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="angkatan" class="form-label">Berdasarkan Angkatan</label>
                            <select name="angkatan" id="angkatan" class="form-select">
                                <option value="semua">-- Semua Angkatan --</option>
                                 <?php $__currentLoopData = $allAngkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angkatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($angkatan); ?>"><?php echo e($angkatan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="card-footer text-end">
                        <button type="submit" class="btn btn-primary">Download PDF</button>
                    </div>
                </form>
            </div>
        </div>

        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-download me-2"></i>Download Data Dosen</h3>
                </div>
                
                <form action="<?php echo e(route('dosen.download')); ?>" method="GET" target="_blank">
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="prodi_id_dosen" class="form-label">Berdasarkan Prodi</label>
                            <select name="prodi_id" id="prodi_id_dosen" class="form-select">
                                <option value="semua">-- Semua Prodi --</option>
                                <?php $__currentLoopData = $allProdi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($prodi->id); ?>"><?php echo e($prodi->nama_prodi); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="card-footer text-end">
                        <button type="submit" class="btn btn-primary">Download PDF</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\221280104\resources\views/dashboard.blade.php ENDPATH**/ ?>